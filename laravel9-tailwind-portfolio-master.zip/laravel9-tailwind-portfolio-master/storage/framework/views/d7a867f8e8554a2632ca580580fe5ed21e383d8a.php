<h3>You have contact request</h3>
<table>
  <tr>
    <th>Name</th>
    <td><?php echo e($name); ?></td>
  </tr>
  <tr>
    <th>Email</th>
    <td><?php echo e($email); ?></td>
  </tr>
</table>

<div>
  <?php echo e($body); ?>

</div>
<?php /**PATH C:\xampp\htdocs\laravel9-tailwind-portfolio-master\resources\views/email/contact.blade.php ENDPATH**/ ?>