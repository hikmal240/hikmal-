<x-call-to-action>
  <x-slot:title>

    <h2 class=" text-white font-bold text-3xl sm:text-[38px] leading-tight mb-2 sm:mb-3 lg:mb-0 ">

</x-call-to-action>
