<button
    {{ $attributes->merge(['id' => 'navbarToggler', 'class' => 'block absolute right-4 top-1/2 -translate-y-1/2 lg:hidden focus:ring-2 ring-primary px-3 py-[6px] rounded-lg ']) }}
>
    <span class="relative w-[30px] h-[2px] my-[6px] block bg-body-color"></span>
    <span class="relative w-[30px] h-[2px] my-[6px] block bg-body-color"></span>
    <span class="relative w-[30px] h-[2px] my-[6px] block bg-body-color"></span>
</button>
